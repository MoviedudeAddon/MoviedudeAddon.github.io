# Copyright (C) 2023, Roman V. M.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""
Example video plugin that is compatible with Kodi 20.x "Nexus" and above
"""
import os
import sys
from urllib.parse import urlencode, parse_qsl

import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from xbmcvfs import translatePath

# Get the plugin url in plugin:// notation.
URL = sys.argv[0]
# Get a plugin handle as an integer number.
HANDLE = int(sys.argv[1])
# Get addon base path
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
FANART_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'fanart')

# Public domain movies are from https://publicdomainmovie.net
# Here we use a hardcoded list of movies simply for demonstrating purposes
# In a "real life" plugin you will need to get info and links to video files/streams
# from some website or online service.
VIDEOS = [
    {
        'genre': 'Tamil Movies',
        'icon': os.path.join(ICONS_DIR, 'Tamilmovies.png'),
        'fanart': os.path.join(FANART_DIR, 'tamilart.jpg'),
        'movies': [
             {
                'title': 'Jailer',
                'url': 'https://pub-0243b9efd12e468ab758868996cc5d4f.r2.dev/686862862/1018249.mkv',
                'poster': 'https://m.media-amazon.com/images/M/MV5BMTJmZmQ2OGUtZTg0NS00ZmYzLWJjOGItYmFkNGYwMDM0NTQxXkEyXkFqcGdeQXVyMTY3ODkyNDkz._V1_.jpg',
                'plot': 'A retired jailer embarks on a quest to find his sons killers.',
                'year': 2023,
            },
            {
                'title': 'Thunivu',
                'url': 'https://evif.onthecloudcdn.com/_v10/26a963926894dd79c91cfed3ae21c41ae573a030ca6e470108122e66bc280bab22221c0a60ee07a32b6c98f7e97f8699dec29b1c6f91bf5003baf18fc3d1b86fb094bfab8cee1078c2bcc9c5dbd86b6a580f70d33f30256cfcc2f821df72c19eb67589ada2c90f2eedcfb595dcd4068ffe593be712b43c770004f3933211b7f4eafa3e771c90c2f5c7efd1983241d197/1080/index.m3u8',
                'poster': 'https://i.ibb.co/k16gbzB/Thunivu-result.jpg',
                'plot': 'A criminal mastermind and his team form a plan and commit bank heists across Chennai but the motive of their heists remains mysterious.',
                'year': 2023,
            },
            {
                'title': 'Thuppakki',
                'url': 'https://evif.onthecloudcdn.com/_v10/e5c31f00be14e734a24045327adaf74cbaadf37274844b35649a06c528513c716f8d3b009b7d0489c690f586898a0d5218136119775f0d28b2db6ca49091a201afe465e27451fc090f7c2f259b47ec68cff09d96262c33a4d74f975464f586a5b055c9a0dade5b380a8db4d9f91f0c8fbb65c56507b222f348ee5d2a87a07e0f/480/index.m3u8',
                'poster': 'http://4.bp.blogspot.com/-GOtb0tBp_lg/T584adB6j6I/AAAAAAAAFt4/ntX5H39s7mQ/s1600/472324_10150851695671468_203810981467_11931019_1740665018_o.jpg',
                'plot': 'Thuppakki is a 2012 Indian Tamil-language action thriller film written and directed by AR Murugadoss. Produced by Kalaipuli S. Thanu of V Creations the film stars Vijay and Kajal Aggarwal with Sathyan Vidyut Jammwal Jayaram Manobala and Zakir Hussain in supporting roles.',
                'year': 2012,
            },
        ],
    },
    {
        'genre': 'Dubbed Movies',
        'icon': os.path.join(ICONS_DIR, 'Dubbedmovies.png'),
        'fanart': os.path.join(FANART_DIR, 'Dubbedart.jpg'),
        'movies': [
             {
                'title': 'Pushpa The Rise',
                'url': 'https://newtamilmovies.in/assets1/2021TamiliMovies/Pushpa.mp4',
                'poster': 'https://stat1.bollywoodhungama.in/wp-content/uploads/2021/07/Pushpa-4.jpg',
                'plot': 'Violence erupts between red sandalwood smugglers and the police charged with bringing down their organization.',
                'year': 2021,
            },
            {
                'title': 'ShangChi and the Legend of the Ten Rings',
                'url': 'https://newtamilmovies.in/assets1/2021TamilDubMovie/Shang-Chi.mp4',
                'poster': 'https://www.newdvdreleasedates.com/images/movies/shang-chi-and-the-legend-of-the-ten-rings-2021.jpg',
                'plot': 'Martialarts master ShangChi confronts the past he thought he left behind when he drawn into the web of the mysterious Ten Rings organization.',
                'year': 2021,
            },
            {
                'title': 'Jungle Cruise',
                'url': 'https://newtamilmovies.in/assets1/2021TamilDubMovie/Jungle%20Cruise.mp4',
                'poster': 'http://image.tmdb.org/t/p/original/3UPz63cGsAQlYQnkOHfAbUhl1O3.jpg',
                'plot': 'Dr. Lily Houghton enlists the aid of wisecracking skipper Frank Wolff to take her down the Amazon in his ramshackle boat. Together they search for an ancient tree that holds the power to heal a discovery that will change the future of medicine.',
                'year': 2021,
            },
        ],
    },
     {
          'genre': 'English Movies',
          'icon': os.path.join(ICONS_DIR, 'Englishmovies.png'),
          'fanart': os.path.join(FANART_DIR, 'Englishart.jpg'),
          'movies': [
              {
                'title': 'E.M.P. 333 Days',
                'url': 'https://eno.dokicloud.one/_v10/357cc77133b1f32266c69282f4a380d48035e92d1348280a7fce9ff000b944bf05a1d2f3309f5e50bbdceba180aaee83b9e7c0c071f28add68843ab1e7d655fc27bd6f7cdb4265757c76bdc4c2cebe687ba1a49eec55a5fed62af4e74a22ee88f8159419f2b447b6b887b3586be79ef0f45d0802d8725204a8850cbcb7fe3c39/720/index.m3u8',
                'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/bN8j5zAeHr2Xs3weBhd22A7KT6f.jpg',
                'plot': 'After an E.M.P weapon is deployed North America is forced to live in preindustrial conditions. Anything electrical is useless sending North American nations into anarchy. An introverted 11 year old girl must fend and fight for herself while trying to find her father.',
                'year': 2018,
            },
            {
                'title': 'CHiPs',
                'url': 'https://neves.jeffycontent.com/_v10/070d1dc4336580b510a4ef056c0b3c998f387dc52a7de5912655673e289cc7bd2bc165718c26011b8db01374375e041ebc73b4675f6f31ebbcd6a196f59b7b39ca5ee5a857411021d5be98d4ea4e30f4fac8c7cc4e29e088fa92813b080439502f7d7d8436e2c62b5317bfbc9304500911dbbb6b5c20c57fa2337b9ac0dc1ea700fa24bbe6203c05fc592a7c1dfaf3d3/1080/index.m3u8',
                'poster': 'https://image.tmdb.org/t/p/original/poCQnJBJ3AGIChI5BwgsfnTf4WW.jpg',
                'plot': 'Jon Baker and Frank Ponch Poncherello have just joined the California Highway Patrol in Los Angeles but for very different reasons. Baker is a former motorbike rider whos trying to put his life and marriage back together. Poncherello is a cocky undercover FBI agent whos investigating a multimillion dollar heist that may be an inside job..',
                'year': 2017,
            },
            {
                'title': 'SpiderMan Homecoming',
                'url': 'https://eno.dokicloud.one/_v10/7c18fd3334f5118123500dbbda17ddce4444186348d8d0cc2b90546004dca5c9763dda0dc72b7bcfee3235c50ea4ebf18e100edbf4c9a17cd827a8b27e2bf330e7aba24e79a23215aa12a43e916425d7fc77d10c1d936fb84c977d60b42149f441da3362778eeb6da549f51f8420a21daece53b0fa4fcb5aadea7e8c6e2210530035c655b456cf7e5ab4950570fbe99a/1080/index.m3u8',
                'poster': 'https://image.tmdb.org/t/p/original/kY2c7wKgOfQjvbqe7yVzLTYkxJO.jpg',
                'plot': 'Thrilled by his experience with the Avengers young Peter Parker returns home to live with his Aunt May. Under the watchful eye of mentor Tony Stark Parker starts to embrace his newfound identity as SpiderMan. He also tries to return to his normal daily routine distracted by thoughts of proving himself to be more than just a friendly... ',
                'year': 2017,
            },
        ],
    },
     {
        'genre': 'Hindi Movies',
        'icon': os.path.join(ICONS_DIR, 'Hindimovies.png'),
        'fanart': os.path.join(FANART_DIR, 'Hindiart.jpg'),
        'movies': [
              {
                'title': 'Pathaan',
                'url': 'https://d2.openfile.online/downloads/0sRZgjzlEsMwnkLYin08xQ/1693061034/d/Tamil%20Movies/Tamil%202023%20Movies/Pathaan%20(2023)/Pathaan%20(2023)%20HDRip/Pathaan%20(640x360)/Pathaan%20(2023)%20HDRip%20Single%20Part%20(640x360).mp4',
                'poster': 'https://cdn.bollywoodmdb.com/fit-in/movies/largethumb/2022/pathan/pathan-poster-8.jpg',
                'plot': 'An Indian spy battles against the leader of a gang of mercenaries who have a heinous plot for his homeland.',
                'year': 2023,
            },
        ],
    },
     {
        'genre': 'Web Series',
        'icon': os.path.join(ICONS_DIR, 'Series.png'),
        'fanart': os.path.join(FANART_DIR, 'Seriesart.jpg'),
        'movies': [
              {
                'title': 'Squid Game',
                'url': 'https://newtamilmovies.in/assets1/2021TamilDubMovie/Squid_Game.mp4',
                'poster': 'https://geekculture.co/wp-content/uploads/2021/09/squid-game.jpeg',
                'plot': 'Squid Game is a South Korean survival drama television series created by Hwang Donghyuk for Netflix. Its cast includes Lee Jungjae Park Haesoo Wi Hajoon HoYeon Jung O Yeongsu Heo Sungtae Anupam Tripathi and Kim Jooryoung. The series revolves around a secret contest where 456 players all of whom are in deep financial hardship risk...',
                'year': 2021,
            },
            {
                'title': 'Mathagam',
                'url': 'https://pub-0243b9efd12e468ab758868996cc5d4f.r2.dev/686862862/1040517.mkv',
                'poster': 'https://m.media-amazon.com/images/M/MV5BOGQ1YWRmNjQtZTc2YS00NjdiLTk0YTEtZWEyMTllM2FjODVmXkEyXkFqcGdeQXVyMTUzNTgzNzM0._V1_FMjpg_UY601_.jpg',
                'plot': 'A sincere IPS officer who takes on a crime syndicate led by an evil mastermind. Stars. Sharath Ravi. Nikhila Vimal. Gautham Vasudev Menon.',
                'year': 2023,
            },
            {
                'title': 'My Girlfriend Is an Alien',
                'url': 'https://cdn.jwplayer.com/manifests/kaARrDnu.m3u8',
                'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/5e2owvs9TWVsuIacTFxJGPp6KVW.jpg',
                'plot': 'My Girlfriend Is An Alien is a 2019 Chinese television series starring Wan Peng with Thassapak Hsu. It aired on Tencent Video and WeTV from August 19 to September 24 2019. The second season aired on Tencent Video and WeTV from September 16 2022.',
                'year': 2019,
            },
        ],
    },
    {
        'genre': 'Live TV',
        'icon': os.path.join(ICONS_DIR, 'Livetv.png'),
        'fanart': os.path.join(FANART_DIR, 'Tvart.jpg'),
        'movies': [
               {
                'title': 'Colors Tamil',
                'url': 'http://moviedue.byethost31.com/playlist/tamil/suntv.m3u8',
                'poster': 'https://www.indiantvinfo.com/media/2017/05/colors-tamil-logo-latest.png',
                'plot': 'Colors Tamil HD is an Indian Tamil language general entertainment pay television channel owned by Viacom 18...',
                'year': 0,
            },
            {
                'title': 'Sun TV',
                'url': 'http://moviedue.byethost31.com/playlist/tamil/suntv.php',
                'poster': 'https://upload.wikimedia.org/wikipedia/en/thumb/6/6a/Sun_TV_logo.svg/1200px-Sun_TV_logo.svg.png',
                'plot': 'Sun TV is an Indian Tamil language movie channel owned by the Sun TV Network.',
                'year': 0,
            },
            {
                'title': 'KTV',
                'url': 'http://moviedue.byethost31.com/playlist/tamil/ktv.m3u8',
                'poster': 'https://upload.wikimedia.org/wikipedia/en/d/d8/KTV_India_logo.png',
                'plot': 'K TV (Kondattam TV) is an Indian Tamil language movie channel owned by the Sun TV Network.',
                'year': 0,
            },
             {
                'title': 'Raj Digital',
                'url': 'http://moviedue.byethost31.com/playlist/tamil/rajdigital.m3u8',
                'poster': 'https://www.tvchannelpricelist.com/wp-content/uploads/channels-logo-300/raj-digital-plus-logo-300x300.jpg',
                'plot': 'Raj Digital Plus is one of the popular Tamil TV Entertainment channel..',
                'year': 0,
            },
             {
                'title': 'Sun Music',
                'url': 'http://moviedue.byethost31.com/playlist/tamil/sunmusic.m3u8',
                'poster': 'https://www.sundirect.in/Content/Uploads/Blocks/636928288240842877_sun-music-hd.png',
                'plot': 'Sun Music is the oldest and most popular Tamil music channel in India and the only one to be available in HD.',
                'year': 0,
            },
             {
                'title': 'Siripoli',
                'url': 'http://moviedue.byethost31.com/playlist/tamil/siripoli.m3u8',
                'poster': 'https://tamilultra.net/wp-content/uploads/2023/06/Sirippoli_TV.png',
                'plot': 'The Sirippoli TV channel is a part of the Kalaignar TV Network Pvt Ltd and is dedicated to providing entertainment exclusively for Comedy fans.',
                'year': 0,
            },
              {
                'title': 'Murasu',
                'url': 'https://segment.yuppcdn.net/050522/murasu/playlist.m3u8',
                'poster': 'https://4.bp.blogspot.com/-dcsyaJEZ0Rk/VjBzxfZO0TI/AAAAAAAAAFU/9jRA3tmff_E/s320/murasu%2Btv%2Blogo-yupptv.jpg',
                'plot': 'Kalaignar Murasu was refreshed in to movie channel In Weekdays It airs old movies on 6am 11am and 15pm In Weekdays Evening It airs Super Hit Movies on 18pm...',
                'year': 0,
            },
             {
                'title': 'IBC Tamil',
                'url': 'https://tx1.ibctamil.tv/CDN_IBC_Canada/index.m3u8?k=5',
                'poster': 'https://yt3.ggpht.com/a-/AAuE7mB7tH9HV1x71MpCtBDq-aVuqQZSyFTGDtYVTQ=s900-mo-c-c0xffffffff-rj-k-no',
                'plot': 'IBC Tamil is one of the popular Tamil TV Entertainment channel.',
                'year': 0,
            },
             {
                'title': 'IBC Comedy',
                'url': 'https://tx1.ibctamil.tv/CDN_IBC_Pakidi/index.m3u8?s=2',
                'poster': 'https://d229kpbsb5jevy.cloudfront.net/st-ak/yupptv/roku/images/skyworth/v5/IBC_Comedy-new_roku.jpg',
                'plot': 'IBC Comedy is one of the popular Tamil TV Entertainment channel.',
                'year': 0,
            },
               {
                'title': 'Makkal TV',
                'url': 'http://5k8q87azdy4v-hls-live.wmncdn.net/MAKKAL/271ddf829afeece44d8732757fba1a66.sdp/index.m3u8',
                'poster': 'https://yt3.googleusercontent.com/ytc/AOPolaRdJ735Au-pmMlNVCZQkwn39HSq7zCb-pN16xT7=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Makkal TV is a unique infotainment media initiative in the Tamil satellite TV scape launched with a definite objective of creating value for the viewers',
                'year': 0,
            },
             {
                'title': 'Vasanth TV',
                'url': 'http://vasanth.live-s.cdn.bitgravity.com/cdn-live/_definst_/vasanth/secure/live/feed01/playlist.m3u8?e=0&h=54e44f64b2e6d5122acdf77d01ab7f9f',
                'poster': 'https://play-lh.googleusercontent.com/w4Linnw16zkXQpl07YXCvhRZa6xjv5xIA6eTjP0Ik4OpSMiDae34s3V0vQS9hta1vMlE',
                'plot': 'Vasanth TV is a Tamil entertainment satellite channel which is owned by MLA H Vasanthakumar of Vasanth & Co Group...',
                'year': 0,
            },
            {
                'title': 'Velicham TV',
                'url': 'https://rtmp.smartstream.video/velichamtv/velichamtv/playlist.m3u8',
                'poster': 'https://yt3.googleusercontent.com/pMU6DtaCgjdYfmpgJajs4QJOMv5ycxnO3ECsrnUVwK2saIruFBiqmqZ3F4RYdGEFUKzn1E81=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Velicham TV is a Tamil TV Channel based in Chennai Tamil Nadu India.',
                'year': 0,
            },
             {
                'title': 'Vasantham TV',
                'url': 'https://j78dp2pnlq5r-hls-live.comcities.net/ITNDigital/20a317b0496a4930b375290505e5d628.sdp/playlist_dvr.m3u8?e=1',
                'poster': 'https://yt3.ggpht.com/a/AGF-l78B4cf9FrZYPW8zLs3RnKEjHwYBk2mNWhyl6Q=s900-c-k-c0xffffffff-no-rj-mo',
                'plot': 'The Independent Television Network The pioneer television station in Sri Lanka.',
                'year': 0,
            },
            {
                'title': 'Vanavil TV',
                'url': 'https://livetv-channels.b-cdn.net/8045/chunklist0.m3u8',
                'poster': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNgU7NF54IVYt70g2EkiPIAjeB7V_kYcY3jV0uEPsqbKOdPXdhQRR6YBDVj9kqiiWswD0&usqp=CAU',
                'plot': 'VAANAViL Television is a new age Tamil satellite channel which officially began broadcasting on 14th February 2016. ',
                'year': 0,
            },
            {
                'title': 'Vikatan TV',
                'url': 'https://d35j504z0x2vu2.cloudfront.net/v1/master/0bc8e8376bd8417a1b6761138aa41c26c7309312/vikatan-tv/master.m3u8',
                'poster': 'https://yt3.googleusercontent.com/ytc/AOPolaSs-om3v0kihe3ZBMlo_ErRjxyouyEVlwO3-K6YPA=s176-c-k-c0x00ffffff-no-rj',
                'plot': 'Vikatan Political news perspectives commentary satire',
                'year': 0,
            },
             {
                'title': 'Shakthi TV',
                'url': 'https://edge4-moblive.yuppcdn.net/transsd/smil:shakthitv.smil/playlist.m3u8?g=3',
                'poster': 'https://yt3.ggpht.com/a/AATXAJz9xrqJMKbWiVBTvMBdCG5S_6ibRb2shTtxgA=s900-c-k-c0xffffffff-no-rj-mo',
                'plot': 'Shakthi TV is the first Tamil television service of Sri Lanka It is the number one Tamil station in Sri Lanka.',
                'year': 0,
            },
              {
                'title': '3 Tamil TV',
                'url': 'https://6n3yogbnd9ok-hls-live.5centscdn.com/threetamil/d0dbe915091d400bd8ee7f27f0791303.sdp/index.m3u8',
                'poster': 'https://yt3.googleusercontent.com/ytc/AOPolaQQADPVPNiyxtcqPhkwScvKzma7okw_IaYLCKor=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Enjoy the Indian Tamil Channel from the Aussie Land Broadcast from Melbourne to develop the Tamil Community.',
                'year': 0,
            },
            {
                'title': 'CSK TV',
                'url': 'https://galaxyott.live/hls/csktv.m3u8',
                'poster': 'https://yt3.googleusercontent.com/ytc/AOPolaQQADPVPNiyxtcqPhkwScvKzma7okw_IaYLCKor=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Tamil local cable tv channel',
                'year': 0,
            },
             {
                'title': 'Isai Saral',
                'url': 'http://bmlive.net:8000/srmusix/srmusix/bms.m3u8',
                'poster': 'https://yt3.googleusercontent.com/Mwzkpb1ezVIEZBt4k4TkGHbluGhyB8idR_vJjgVsRK5WiyvvT2ttNsBuxti9Plr4289u81ZImQ=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Enjoy the Indian Tamil Music Channel...',
                'year': 0,
            },
            {
                'title': 'NewsTamil 24X7',
                'url': 'https://utube.psrutube.workers.dev/stream/UCtbo6_eDG7zEtaOtcSltJkA/master.m3u8',
                'poster': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3xlPpEgRWqgJExQZXddetgVkLRIY3JUxI_x6kbR-rZmjGVwGeV0IC1v-lRJQ5fOJ26fs&usqp=CAU',
                'plot': 'News Tamil 24x7 is a 24hour Tamil news channel. News Tamil 24x7 brings you the latest news on politics economy sports panel discussions with eminent ...',
                'year': 0,
            },
             {
                'title': 'Polimer News',
                'url': 'https://utube.psrutube.workers.dev/stream/UC8Z-VjXBtDJTvq6aqkIskPg/master.m3u8',
                'poster': 'https://yt3.googleusercontent.com/ytc/AOPolaTVP-PS5xXZvhcH8xxuc8FmO5tzgUttxGwav5YehCA=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Polimer News brings unbiased News and accurate information to the socially conscious common man.',
                'year': 0,
            },
             {
                'title': '9XM',
                'url': 'https://livectv.phando.com/8067/chunklist0.m3u8',
                'poster': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeK9NUxw9zJXPW5NBlHnLClBel02WUgb2NdpL_K6sgG_C1M98qXfKdnzhcapLJFpQIzfs&usqp=CAU',
                'plot': 'Enjoy the Indian Music Channel...',
                'year': 0,
            },
             {
                'title': 'Sony Kal',
                'url': 'https://spt-sonykal-1-us.lg.wurl.tv/playlist.m3u8',
                'poster': 'https://yt3.googleusercontent.com/OllE6a28oXMQsCZVCHk1C-cc78ZG0B97NMo3WyyEe0FdVrQ9b3Gv8psoUHKFcW_EojggaNE=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Sony KAL Hindi is a general entertainment destination featuring the most iconic celebrated and award-winning drama and comedy television series direct ..',
                'year': 0,
            },
            {
                'title': 'Discovery Kids',
                'url': 'https://cdn-apse1-prod.tsv2.amagi.tv/linear/amg01448-samsungin-discoverykids-samsungin/playlist.m3u8',
                'poster': 'https://yt3.googleusercontent.com/FtODE6EvAzB07vITsG4w1ZrQnAXK0Dv3d-kVU8Br9x31GQtmLgGu2Dn2_CBaON5l2oWcGloyAQ=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Discovery Kids is an Indian cable and satellite television channel operated by Warner Bros Discovery India.',
                'year': 0,
            },
             {
                'title': 'Nick HD+',
                'url': 'https://prod-sports-north-gm.jiocinema.com/bpk-tv/Nick_HD_Plus_voot_MOB/Fallback/index.m3u8',
                'poster': 'https://www.tvchannelpricelist.com/wp-content/uploads/channels-logo-300/nicks-hd-plus-logo-300x300.jpg',
                'plot': 'Nickelodeon HD+ (abbreviated as Nick HD+) is an Indian childrens pay television channel based in Mumbai Maharashtra India.',
                'year': 0,
            },
            {
                'title': 'Nick Jr',
                'url': 'https://prod-sports-north-gm.jiocinema.com/bpk-tv/Nick_Junior_voot_MOB/Fallback/index.m3u8',
                'poster': 'https://yt3.googleusercontent.com/jHP1_0bbTYI-o_tEprn8w_Qy7bJdqMLS_ChsdXg2IBPnKpFasvIV0TbqerIly2w4AUZ46ZJ1EA=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Nick Jr is a channel for toodlers where favourite shows like Paw Patrol Dora the Explorer Go Deigo Go and many more which helps your kid to grow and learn ...',
                'year': 0,
            },
            {
                'title': 'Sonic Nickelodeon',
                'url': 'https://prod-sports-north-gm.jiocinema.com/bpk-tv/Sonic_Nickelodeon_voot_MOB/Fallback/index.m3u8',
                'poster': 'https://i.vimeocdn.com/video/615699447-67e42e4986bcc0e5d7e7cdd7196c409b4d2c9edf6090ec81b3b1bcc18526bdda-d',
                'plot': 'Nickelodeon Sonic (formerly Sonic-Nickelodeon) is an Indian childrens pay television channel operated by Viacom18 as part of the Nickelodeon India network.',
                'year': 0,
            },
             {
                'title': 'HBO',
                'url': 'http://185.188.188.235/live/hbo/playlist.m3u8',
                'poster': 'https://yt3.googleusercontent.com/kQnKDFuopB13RAVEPROdtKEatDF6J5T86HhNeEX2ysAsx3_USNQjhYBFrjAQRsoPQTVYQRnX=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Home Box Office (HBO) is an American pay television network which is the flagship property of namesake parent-subsidiary Home Box Office',
                'year': 0,
            },
             {
                'title': 'HBO 2',
                'url': 'http://185.188.188.235/live/hbo2/playlist.m3u8',
                'poster': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5tXaf7i7mMAHB4a8PPlOcfmNaV-iXiU0swfVc2R85U-hPDEPQiYl1G-Zt07Q102UITA4&usqp=CAU',
                'plot': 'Home Box Office 2 (HBO) is an American pay television network which is the flagship property of namesake parent-subsidiary Home Box Office 2',
                'year': 0,
            },
             {
                'title': 'DD Sports',
                'url': 'https://livectv.phando.com/8014/playlist.m3u8',
                'poster': 'https://www.indiantvinfo.com/media/2022/07/DD-Sports-Live.jpg',
                'plot': 'DD Sports is an sports television channel telecasting from Central Production Centre in Delhi India. It is a part of the Doordarshan family of networks',
                'year': 0,
            },
            {
                'title': 'Willow HD',
                'url': 'http://62.182.85.213:8089/live/Z0E8ld964aFDuVe/MD4Efa09Cr2k8uG/60e1e48b-6e6b-4ea2-9a8b-ce7040c71378.m3u8',
                'poster': 'https://yt3.googleusercontent.com/ytc/AOPolaR912ipQngFNlMUCBXmXgVyL2J6iRMzbTTwoAQnFg=s900-c-k-c0x00ffffff-no-rj',
                'plot': 'Willow TV International is the largest broadcaster of cricket in the United States and Canada. It operates the only 24x7 HD Channel on all major television ..',
                'year': 0,
            },
            {
                'title': 'EuroSports',
                'url': 'https://cdn-apse1-prod.tsv2.amagi.tv/linear/amg01448-samsungin-eurosporthdin-samsungin/playlist.m3u8',
                'poster': 'https://i.eurosport.com/2015/11/12/1731141-36621047-640-480.jpg',
                'plot': 'Eurosport is your go to source for sport news on demand videos commentary & highlights all in one place.',
                'year': 0,
            },
            {
                'title': 'ESTV',
                'url': 'https://estv-rakuten.amagi.tv/playlist_1080p.m3u8',
                'poster': 'https://static-cdn.jtvnw.net/jtv_user_pictures/98cc7462-8719-4b41-9b53-5b9f36d510e8-profile_image-300x300.png',
                'plot': 'ESTV (Esports TV) is the worlds first 24/7 live linear and AVOD esports channel available everywhere.',
                'year': 0,
            },
            {
                'title': 'CBC TV 8',
                'url': 'https://1740288887.rsc.cdn77.org/1740288887/index.m3u8',
                'poster': 'https://upload.wikimedia.org/wikipedia/en/9/90/CBC_TV_8.png',
                'plot': 'CBC TV 8 is a television station owned and operated by public broadcaster Caribbean Broadcasting Corporation in Barbados.',
                'year': 0,
            },
            {
                'title': 'TVG',
                'url': 'http://190.80.3.28/TVG/TVG.isml/index.m3u8',
                'poster': 'https://static.wikia.nocookie.net/logopedia/images/6/6b/Television_Guyana_Logo.png/revision/latest?cb=20211229205320',
                'plot': 'TVG is among the most widely distributed horseracing networks in the world.',
                'year': 0,
            },
            {
                'title': 'TNT Sports 1',
                'url': 'https://us.catchystream.xyz/playlist/stream_3.m3u8',
                'poster': 'https://cdn.comedy.co.uk/images/channels/tnt_sports_1.jpg',
                'plot': 'Watch the latest sporting events that are happening right now on TNT Sports 1.',
                'year': 0,
            },
            {
                'title': 'Viaplay xtra',
                'url': 'https://d3j7ofexbkp7q4.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-bl5ti7t9yiazp-ssai-prd/master.m3u8',
                'poster': 'https://eyescoreshop.com/wp-content/uploads/2021/05/Viaplay-1-600x600.jpg',
                'plot': 'Viaplay is a leading streamer of European entertainment now available to you in the US. Viaplay brings you over 2000 hours of critically acclaimed content',
                'year': 0,
            },
        ],
    },
]


def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :return: plugin call URL
    :rtype: str
    """
    return '{}?{}'.format(URL, urlencode(kwargs))


def get_genres():
    """
    Get the list of video genres

    Here you can insert some code that retrieves
    the list of video sections (in this case movie genres) from some site or API.

    :return: The list of video genres
    :rtype: list
    """
    return VIDEOS


def get_videos(genre_index):
    """
    Get the list of videofiles/streams.

    Here you can insert some code that retrieves
    the list of video streams in the given section from some site or API.

    :param genre_index: genre index
    :type genre_index: int
    :return: the list of videos in the category
    :rtype: list
    """
    return VIDEOS[genre_index]


def list_genres():
    """
    Create the list of movie genres in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(HANDLE, 'Home')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(HANDLE, 'movies')
    # Get movie genres
    genres = get_genres()
    # Iterate through genres
    for index, genre_info in enumerate(genres):
        # Create a list item with a text label.
        list_item = xbmcgui.ListItem(label=genre_info['genre'])
        # Set images for the list item.
        list_item.setArt({'icon': genre_info['icon'], 'fanart': genre_info['fanart']})
        # Set additional info for the list item using its InfoTag.
        # InfoTag allows to set various information for an item.
        # For available properties and methods see the following link:
        # https://codedocs.xyz/xbmc/xbmc/classXBMCAddon_1_1xbmc_1_1InfoTagVideo.html
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        info_tag = list_item.getVideoInfoTag()
        info_tag.setMediaType('video')
        info_tag.setTitle(genre_info['genre'])
        info_tag.setGenres([genre_info['genre']])
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&genre_index=0
        url = get_url(action='listing', genre_index=index)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)
    # Add sort methods for the virtual folder items
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(HANDLE)


def list_videos(genre_index):
    """
    Create the list of playable videos in the Kodi interface.

    :param genre_index: the index of genre in the list of movie genres
    :type genre_index: int
    """
    genre_info = VIDEOS[genre_index]
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(HANDLE, genre_info['genre'])
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(HANDLE, 'movies')
    # Get the list of videos in the category.
    videos = genre_info['movies']
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label
        list_item = xbmcgui.ListItem(label=video['title'])
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use only poster for simplicity's sake.
        # In a real-life plugin you may need to set multiple image types.
        list_item.setArt({'poster': video['poster']})
        # Set additional info for the list item via InfoTag.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        info_tag = list_item.getVideoInfoTag()
        info_tag.setMediaType('movie')
        info_tag.setTitle(video['title'])
        info_tag.setGenres([genre_info['genre']])
        info_tag.setPlot(video['plot'])
        info_tag.setYear(video['year'])
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=https%3A%2F%2Fia600702.us.archive.org%2F3%2Fitems%2Firon_mask%2Firon_mask_512kb.mp4
        url = get_url(action='play', video=video['url'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)
    # Add sort methods for the virtual folder items
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(HANDLE)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    # offscreen=True means that the list item is not meant for displaying,
    # only to pass info to the Kodi player
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath(path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if not params:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_genres()
    elif params['action'] == 'listing':
        # Display the list of videos in a provided category.
        list_videos(int(params['genre_index']))
    elif params['action'] == 'play':
        # Play a video from a provided URL.
        play_video(params['video'])
    else:
        # If the provided paramstring does not contain a supported action
        # we raise an exception. This helps to catch coding errors,
        # e.g. typos in action names.
        raise ValueError(f'Invalid paramstring: {paramstring}!')


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
